<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
$html='';
if(!empty($files)){
    foreach ($files as $row) {
        $html .='<tr><td>'.$row['upload_file'].'</td><td>'.date('Y-m-d H:i:s',$row['created_date']).'</td></tr>';
    }
}

?>
<div class="container mt-5">
    <form method="post" id="login_form" class="mb-100" enctype="multipart/form-data">
        <div class="mobile-form">
            <h4 class="title text-center mb-50">upload Files</h4>
            <div class="mb-4">
                <div class="custom-file">
                <input type="file" class="custom-file-input" id="fileToUpload" name="fileToUpload">
                <label class="custom-file-label" for="fileToUpload">Choose file</label>
                </div>
            </div>
            <button type="submit" name="submit" class="btn" style="width: 100%;">Upload</button>
        </div>
    </form>
    <table id="example" class="table table-striped table-bordered mt-5" style="width:100%">
        <thead>
            <tr>
                <th>File Name</th><th>Created Date</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $html;?>
        </tbody>
    </table>
    <p id="message"></p>
    </form>
</div>