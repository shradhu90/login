
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
          $(document).ready(function(){
            $('.only-number').keypress(function(event) {
                var charCode = (event.which) ? event.which : event.keyCode;
                if ((charCode < 48 || charCode > 57)) {
                  event.preventDefault();
                  return false;
                } else {
                  return true;
                }
            });
            
            $('#sendOTP').click(function() {
                var mobile = $('#mobile').val();
                var reg = new RegExp(/^\d+$/);
                var type = $(this).data('type');
                if(mobile != '' && mobile.length == 10 && reg.test(mobile)){
                    
                    $.ajax({
                        url: 'send-otp',
                        type: 'POST',
                        data: {mobile:mobile},
                        success: function(data){
                          if(data==true){
                            $('#message').text('OTP send');
                            $('#otp_box').removeClass('d-none');
                            $('.mobile-form').addClass('d-none');
                            $('#login_number').text(mobile);
                          }
                          else{
                            $('#message').text('OTP Failed! please try again');
                          }
                            
                        }
                    });
                }
            });

            $('#registerBTN').click(function(event) {
                event.preventDefault();
                var mobile = $('#mobile').val();
                var otp = $('#otp').val();
                var reg = new RegExp(/^\d+$/);
                if(mobile != '' && mobile.length == 10 && reg.test(mobile)){
                  if(otp != '' && otp.length == 6 && reg.test(otp)){
                    $.ajax({
                        url: 'check-otp',
                        type: 'POST',
                        data: {mobile:mobile,otp:otp},
                        success: function(data){
                          if(data==true){
                              location.reload();
                          }
                          else{
                            $('#message').text('verification Failed! please try again');
                          }
                            
                        }
                    });
                  }else{
                    alert('fill correct date');
                  }
                    
                }else{
                    alert('fill correct date');
                  }
            });
      });
      </script>
  </body>
</html>