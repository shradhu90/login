<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
$html='';
if(!empty($user)){
    foreach ($user as $row) {
        $html .='<tr><td>'.$row->name.'</td><td>'.$row->mobile_number.'</td><td>'.date('Y-m-d H:i:s',strtotime($row->created_date)).'</td></tr>';
    }
}

?>
<div class="container mt-5">
    <form method="post" id="login_form" class="mb-100" enctype="multipart/form-data">
        <div class="mobile-form">
            <h4 class="title text-center mb-50">Create User</h4>
            <div class="mb-4">
                <input type="text" name="name" class="form-control" placeholder="name" id="mobile" required>
            </div>
            <div class="mb-4">
                <input type="text" name="mobile_number" class="form-control only-number" placeholder="Phone Number" id="mobile" minlength="10" maxlength="10" required>
            </div>
            <button type="submit" name="submit" class="btn" style="width: 100%;">Create User</button>
        </div>
    </form>
    
    <table id="example" class="table table-striped table-bordered mt-5" style="width:100%">
        <thead>
            <tr>
                <th>Name</th><th>Mobile Number</th><th>Created Date</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $html;?>
        </tbody>
    </table>
    </form>
</div>