<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
$ci =& get_instance(); ?>
<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Ass - 1</title>
  </head>
  <body>
    <?php if(isset($this->session->userdata['user']) && $this->session->userdata['user']['user_id'] != ''){ ?>
      <?php if(isset($this->session->userdata['user']) && $this->session->userdata['user']['user_type'] == '1'){?>
      <a href="user">Add user</a>
      <?php } ?>
      &nbsp;<a href="uploadfile">Upload File</a>&nbsp;<a href="logout">Logout</a>
    <?php }?>
    