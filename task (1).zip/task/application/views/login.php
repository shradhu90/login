<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container mt-5">
    <form method="post" id="login_form" class="mb-100">
    <div class="mobile-form">
        <h4 class="title text-center mb-50">Sign In</h4>
        <div class="mb-4">
            <input type="text" name="mobile" class="form-control only-number" placeholder="Phone Number" id="mobile" minlength="10" maxlength="10" required>
        </div>
        <button type="button" class="btn" id="sendOTP" style="width: 100%;">Send OTP</button>
    </div>
    <div class="otp-form d-none" id="otp_box">
        <h4 class="title text-center mb-50">Enter OTP sent to <span id="login_number"></span></h4>
        <div class="mb-4">
        <input type="text" name="otp" minlength="6" maxlength="6" class="form-control" id="otp" required>
        </div>
        <button type="submit" class="btn" id="registerBTN" style="width: 100%;">Verify</button>
    </div>
    <p id="message"></p>
    </form>
</div>