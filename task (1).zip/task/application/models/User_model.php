<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
	function __construct()
	{
		parent::__construct();
	}
	
	function checkMobileNumber(){
        $this->db->select('*');
		$this->db->from('user');
        $this->db->where('mobile_number',$this->input->post('mobile'));
        $query = $this->db->get();
		if($query->num_rows() > 0 ){
			return $query->result();
		}
		else{
			return false;
		}

    }

    function sendOTP($id){

        $rand = mt_rand(100000,999999);
        $array = array(
            'otp'=>$rand
        );
        $this->db->where('id',$id);
        $row = $this->db->update('user',$array);
        if($row){
			return true;
		}
		else{
			return false;
		}
    }
    function checkOtp(){
        $this->db->select('*');
		$this->db->from('user');
        $this->db->where('mobile_number',$this->input->post('mobile'));
        $this->db->where('otp',$this->input->post('otp'));
        $query = $this->db->get();
		if($query->num_rows() > 0 ){
			return $query->result();
		}
		else{
			return false;
		}
    }

    function getUsers(){
        $this->db->select('*');
		$this->db->from('user');
        $query = $this->db->get();
		if($query->num_rows() > 0 ){
			return $query->result();
		}
		else{
			return false;
		}
    }

    function addUser(){
        $array = array(
            'name'=>$this->input->post('name'),
            'mobile_number'=>$this->input->post('mobile_number'),
        );
        $row = $this->db->insert('user',$array);
        if($row){
			return true;
		}
		else{
			return false;
		}
    }

    function getFiles($id){
        $this->db->select('*');
		$this->db->from('user_uploads');
        if($id>0){
            $this->db->where('user_id',$id);
        }
        $query = $this->db->get();
		if($query->num_rows() > 0 ){
			return $query->result();
		}
		else{
			return false;
		}
    }
    
}
?>