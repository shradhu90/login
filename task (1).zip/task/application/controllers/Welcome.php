<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('user_model');
		$this->load->library('upload');
	}

	public function index()
	{
		if(isset($this->session->userdata['user']) && $this->session->userdata['user']['user_id'] != ''){
			redirect('/uploadfile');
			die;
		}
		$this->load->view('header');
        $this->load->view('login');
		$this->load->view('footer');
	}
	public function send_otp()
	{
		if(isset($this->session->userdata['user']) && $this->session->userdata['user']['user_id'] != ''){
			redirect('/uploadfile');
			die;
		}

		$this->form_validation->set_rules('mobile','Mobile number','trim|required');
		if($this->form_validation->run() == true){
			$data = $this->user_model->checkMobileNumber();
			if($data){
				$send = $this->user_model->sendOTP($data[0]->id);
				if($send){
					echo true;die;
				}
			}
		}
		echo false;die;
	}
	public function check_otp()
	{
		if(isset($this->session->userdata['user']) && $this->session->userdata['user']['user_id'] != ''){
			redirect('/uploadfile');
			die;
		}

		$this->form_validation->set_rules('mobile','Mobile number','trim|required');
		$this->form_validation->set_rules('otp','Otp','trim|required');
		if($this->form_validation->run() == true){
			$data = $this->user_model->checkOtp();
			if($data){
				$array = array('user'=>array('user_id'=> $data[0]->id,'user_type'=>$data[0]->user_type));
				$this->session->set_userdata($array);
				echo true;die;
			}
		}
		echo false;die;
	}
	public function user()
	{
		if(!isset($this->session->userdata['user'])){
			redirect('/');
			die;
		}

		$this->form_validation->set_rules('name','name','trim|required');
		$this->form_validation->set_rules('mobile_number','Mobile number','trim|required');
		
		if($this->form_validation->run() == true){
			$data = $this->user_model->addUser();
			if($data){
				$this->session->set_flashdata('success','User added');
			}
			else{
				$this->session->set_flashdata('error','Failed');
			}
			redirect('/user');
		}
		$result['user'] = $this->user_model->getUsers();
		$this->load->view('header');
        $this->load->view('user',$result);
		$this->load->view('footer');
		
	}
	public function uploadFiles()
	{
		if(!isset($this->session->userdata['user'])){
			redirect('/');
			die;
		}
		$id=null;
		if($this->session->userdata['user']['user_type']==1){
			$id = $this->session->userdata['user']['user_id'];
		}

		if (!empty($_FILES['fileToUpload']))
        {
            $config['upload_path'] = 'uploads';
			$config['file_name'] = date('YmdHis');
            $config['file_ext_tolower'] = true;
            $this->load->library('upload', $config);
            if($this->upload->do_upload('fileToUpload'))
            {
                $filedata = $this->upload->data();
                $upload_file = $filedata['file_name'];

				$array = array(
					'user_id'=>$id,
					'upload_file'=>$upload_file,
				);
				$this->db->insert('user_uploads',$array);
			}
			else{
				//print_r($this->upload->display_errors());
			}
		}

		$result['files'] = $this->user_model->getFiles($id);
		$this->load->view('header');
        $this->load->view('uploadfiles',$result);
		$this->load->view('footer');

	}
	public function logout()
	{
		if(isset($this->session->userdata['user'])){
			$this->session->unset_userdata('user');
		}
		redirect('/');
	}
}
